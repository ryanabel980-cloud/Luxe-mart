# LUXE MART — Android app starter

This is a working storefront prototype packaged as a Progressive Web App and ready to be wrapped with Capacitor for Android.

## What works in this prototype
- Perfume, women's slippers and handbag catalog
- Search and category filters
- Cart and checkout form
- Demo order creation and order history
- Local demo admin area for adding/deleting products and marking orders complete
- FCFA pricing and mobile-friendly layout

## Important limitations before real launch
- This prototype stores products, carts and orders in the browser on one device only. It does not yet use a shared online database.
- The admin password is a demo-only client-side password (`luxe2026`). It is NOT secure for a live store.
- MTN MoMo and Orange Money are displayed as checkout choices, but no money is collected. Real payments require a merchant account, an approved payment gateway, server-side transaction verification, and secure backend credentials.
- No real delivery integration or push notifications are configured.

## Build an Android APK
You need a computer with Android Studio, Android SDK, Java, Node.js and internet access.

1. Install Node.js LTS and Android Studio.
2. Extract this project folder.
3. In a terminal, open the project folder and run:
   `npm install`
4. Add Android:
   `npx cap add android`
5. Sync the web app:
   `npx cap sync android`
6. Open Android Studio:
   `npx cap open android`
7. In Android Studio, wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. Android Studio will show the generated APK location.

## Before publishing
Replace the demo order storage with a backend database and secure admin authentication. Integrate MTN MoMo and Orange Money through a supported payment provider. Test successful, failed, cancelled and duplicate payment callbacks before accepting customer payments.
